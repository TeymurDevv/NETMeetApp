﻿using NETMeetApp.Models;

public class Student : User
{
    public int Grade { get; set; }

}